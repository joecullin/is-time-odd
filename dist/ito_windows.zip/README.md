Refer to https://github.com/joecullin/is-time-odd for more info about this app.
